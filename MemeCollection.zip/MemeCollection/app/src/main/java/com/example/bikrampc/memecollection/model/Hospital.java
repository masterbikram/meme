package com.example.bikrampc.memecollection.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Bikrampc on 5/7/2016.
 */
public class Hospital implements Parcelable {
    private String name;
    private String web_address;
    private String email;
    private String contact;
    private String formatted_address;
    private String location;

    protected Hospital(Parcel in) {
        name = in.readString();
        web_address = in.readString();
        email = in.readString();
        contact = in.readString();
        formatted_address = in.readString();
        location = in.readString();
    }
     public Hospital (){

    }
    public Hospital(
             String name,
             String web_address,
             String email,
             String contact,
             String formatted_address,
             String location

             ){
        this.name =name;
        this.web_address =web_address;
        this.email = email;
        this.contact = contact;
        this.formatted_address = formatted_address;
        this.location =location;

    }
    public static final Creator<Hospital> CREATOR = new Creator<Hospital>() {
        @Override
        public Hospital createFromParcel(Parcel in) {
            return new Hospital(in);
        }

        @Override
        public Hospital[] newArray(int size) {
            return new Hospital[size];
        }
    };

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getWeb_address() {
        return web_address;
    }

    public void setWeb_address(String web_address) {
        this.web_address = web_address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getFormatted_address() {
        return formatted_address;
    }

    public void setFormatted_address(String formatted_address) {
        this.formatted_address = formatted_address;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public static Creator<Hospital> getCREATOR() {
        return CREATOR;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {

        dest.writeString(name);
        dest.writeString(web_address);
        dest.writeString(email);
        dest.writeString(contact);
        dest.writeString(formatted_address);
        dest.writeString(location);
    }
}
