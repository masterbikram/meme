package com.example.bikrampc.memecollection.model;

/**
 * Created by Bikrampc on 5/7/2016.
 */

import com.example.bikrampc.memecollection.model.Hospital;

import java.util.ArrayList;

/**
 * Created by noones on 7/12/15.
 */
public class ApiResponse {
    private ArrayList<Hospital> data;
    private boolean ok;
    private String response_type;
    private String action;

    public ArrayList<Hospital> getData() {
        return data;
    }

    public boolean isOk() {
        return ok;
    }

    public void setOk(boolean ok) {
        this.ok = ok;
    }

    public String getResponse_type() {
        return response_type;
    }

    public void setResponse_type(String response_type) {
        this.response_type = response_type;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public void setData(ArrayList<Hospital> data) {
        this.data = data;

    }
}



