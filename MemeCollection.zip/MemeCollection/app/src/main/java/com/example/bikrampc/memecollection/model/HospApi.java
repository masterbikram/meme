package com.example.bikrampc.memecollection.model;

/**
 * Created by Bikrampc on 5/7/2016.
 */
public interface HospApi {

}
